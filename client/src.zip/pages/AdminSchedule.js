import React from "react";
import "../css/AdminSchedule.css";

function AdminSchedule() {
  return <h1>일정관리 임시페이지</h1>;
}

export default AdminSchedule;
