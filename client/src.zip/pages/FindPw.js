import React from "react";
import "../css/common.css";
import "../css/reset.css";
import "../css/main.css";
import "../css/FindPw.css";

function FindPw() {
  return <h1>비밀번호 찾기 임시페이지</h1>;
}

export default FindPw;
