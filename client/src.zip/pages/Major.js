import React from "react";
import "../css/Major.css";
import { Calendar } from "./Calendar";

function Major() {
  return <Calendar />;
}

export default Major;
