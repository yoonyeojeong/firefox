import React from "react";
import "../css/Minor.css";

function Minor() {
  return <h1>2군일정 임시페이지</h1>;
}

export default Minor;
