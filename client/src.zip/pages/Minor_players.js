import React from "react";
import "../css/Minor_players.css";

function Minor_players() {
  return <h1>2군선수 임시페이지</h1>;
}

export default Minor_players;
