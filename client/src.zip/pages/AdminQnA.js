import React from "react";
import "../css/AdminQnA.css";
import AdminQnAContent from "./AdminQnAContent";

function AdminQnA({ qna_id, user_id, nick_name }) {
  return <div className="administrator_qna">1대1 문의 내역 (관리자)</div>;
}

export default AdminQnA;
