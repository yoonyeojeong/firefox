import React from "react";
import "../css/Gallery.css";

function Gallery() {
  return <h1>갤러리 임시페이지</h1>;
}

export default Gallery;
