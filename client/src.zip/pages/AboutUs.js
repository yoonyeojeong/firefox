import React from "react";
import "../css/AboutUs.css";

function AboutUs() {
  return <h1>기획의도 임시페이지</h1>;
}

export default AboutUs;
