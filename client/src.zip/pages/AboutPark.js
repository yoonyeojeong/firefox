import React from "react";
import "../css/AboutPark.css";

function AboutPark() {
  return <h1>야구장소개 임시페이지</h1>;
}

export default AboutPark;
