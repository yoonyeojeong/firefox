import React from "react";
import "../css/AdminPhoto.css";

function AdminPhoto() {
  return <h1>사진등록 임시페이지</h1>;
}

export default AdminPhoto;
