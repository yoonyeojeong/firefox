import React from "react";
import "../css/NeedLogin.css";

function NeedLogin() {
  return <h1>로그인이 필요한 페이지 입니다.</h1>;
}

export default NeedLogin;
